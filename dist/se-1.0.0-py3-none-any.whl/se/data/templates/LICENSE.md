The source text and artwork in this repository are believed to be in the United States public domain; that is, they are believed to be free of copyright restrictions in the United States. Copyright laws vary from country to country, so check your local laws before downloading or using the content in this repository.

The creators of, and contributors to, this repository hereby dedicate their contributions to the worldwide public domain under the terms in the CC0 1.0 Universal Public Domain Dedication, available at <https://creativecommons.org/publicdomain/zero/1.0/>.
