Standard Ebooks and its contributors release the contents of this repository under the GPLv3 license, with the exception of the contents of the `se/data/templates` directory, which are released under the CC0 1.0 Universal Public Domain Dedication.

You can read the GPLv3 license here: http://www.gnu.org/licenses/gpl-3.0.html

You can read the CC0 1.0 Universal Public Domain Dedication here: https://creativecommons.org/publicdomain/zero/1.0/
